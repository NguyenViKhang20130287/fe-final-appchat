import React from "react";
import { Link, useHistory } from "react-router-dom";
import Login_password_option from "./Login_password_option";
import Login_register from "./Login_register";
import { useEffect, useState } from "react";
import { createAsyncThunk } from "@reduxjs/toolkit";

function LoginForm() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const login = () => {
        const payload = {
            action: 'onchat',
            data: {
                event: 'LOGIN',
                data: {
                    user: username,
                    pass: password
                }
            }
        };

        const socket = new WebSocket('ws://140.238.54.136:8080/chat/chat');

        socket.onopen = () => {
            console.log('WebSocket connection established');

            // Send the login payload as a JSON string
            socket.send(JSON.stringify(payload));
        };

        socket.onmessage = (event) => {
            console.log('Received message:', event.data);
            // Handle the received message here
        };

        socket.onclose = () => {
            console.log('WebSocket connection closed');
            // Handle the WebSocket connection closed event
        };
    };

    return (
        <div className="login_body">
            <h3 className="login_title">Đăng nhập</h3>
            <p className="title_sub">Chào mừng bạn đã trở lại với ChatRapid.</p>
            <label htmlFor="username_login">Tên đăng nhập</label>
            <input
                className="login_username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Tên đăng nhập"
                type="text"
                id="username_login"
            />
            <label htmlFor="password_login">Mật khẩu</label>
            <input
                className="login_password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mật khẩu"
                type="password"
                id="password_login"
            />
            <i className="fa-solid fa-eye"></i>
            {/* <i className="fa-regular fa-eye-slash"></i> */}
            <button onClick={login} className="login_button">
                Đăng nhập
            </button>
        </div>
    );
}

export default LoginForm;


// function login(username, password) {
//     const loginData = {
//         action: 'onchat',
//         data: {
//             event: 'LOGIN',
//             data: {
//                 user: username,
//                 pass: password
//             }
//         }
//     };

//     const socket = new WebSocket('ws://140.238.54.136:8080/chat/chat');

//     socket.onopen = () => {
//         // console.log('WebSocket connection established');

//         // Send the login data to the WebSocket server
//         socket.send(JSON.stringify(loginData));

//     };

//     socket.onmessage = (event) => {
//         console.log('Received message:', event.data);
//         // Handle the received message here
//     };

//     socket.onclose = () => {
//         // console.log('WebSocket connection closed');
//         // Handle the WebSocket connection closed event
//     };
// }

// function Login_content() {
//     // const history = useHistory()
//     const [username, setUsername] = useState("")
//     const [password, setPassword] = useState("")
//     useEffect(() => {
//         // Example login function call
//         // login(username, password);
//     }, []);

//     return (<div className="login_body">
//         <h3 className="login_title">Đăng nhập</h3>
//         <p className="title_sub">Chào mừng bạn đã trở lại với ChatRapid.</p>
//         <label for="username_login">Tên đăng nhập</label>
//         <input className="login_username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Tên đăng nhập" type="text" id="username_login" />
//         <label for="password_login">Mật khẩu</label>
//         <input className="login_password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mật khẩu" type="password" id="password_login" />
//         <i class="fa-solid fa-eye"></i>
//         <Login_password_option />
//         {/* <i class="fa-regular fa-eye-slash"></i> */}
//         <button onClick={login(username, password)} className="login_button">Đăng nhập</button>
//         <Login_register />
//     </div >);
// }

// export default Login_content;


// function Login() {
//     const [username, setUsername] = useState("")
//     const [password, setPassword] = useState("")

//     function loginAction(username, password) {
//         const apiLogin = {
//             action: 'onchat',
//             data: {
//                 event: 'LOGIN',
//                 data: {
//                     user: username,
//                     pass: password
//                 }
//             }
//         }
//         const loginClick = createAsyncThunk(
//             // Tên action
//             'auth/login',

//             // Code async logic, tham số đầu tiên data là dữ liệu truyền vào khi gọi action
//             async ({ username, password }) => {
//                 // Gọi lên API backend
//                 const response = await fetch(
//                     'ws://140.238.54.136:8080/chat/chat',
//                     {
//                         method: 'POST',
//                         body: JSON.stringify(apiLogin)
//                     }
//                 );

//                 // Convert dữ liệu ra json
//                 const jsonData = await response.json();
//                 console.log("Successfully!");

//                 // // Nếu bị lỗi thì reject
//                 // if (response.status < 200 || response.status >= 300) {
//                 //     return rejectWithValue(jsonData);
//                 // }

//                 // // Còn không thì trả về dữ liệu
//                 // return jsonData;
//             }
//         );
//         // console.log("Success!");

//     }

//     return (<div className="login_body">
//         <h3 className="login_title">Đăng nhập</h3>
//         <p className="title_sub">Chào mừng bạn đã trở lại với ChatRapid.</p>
//         <label for="username_login">Tên đăng nhập</label>
//         <input className="login_username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Tên đăng nhập" type="text" id="username_login" />
//         <label for="password_login">Mật khẩu</label>
//         <input className="login_password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mật khẩu" type="password" id="password_login" />
//         <i class="fa-solid fa-eye"></i>
//         <Login_password_option />
//         {/* <i class="fa-regular fa-eye-slash"></i> */}
//         <button onClick={loginAction} className="login_button">Đăng nhập</button>
//         <Login_register />
//     </div >);
// }


// export default Login



